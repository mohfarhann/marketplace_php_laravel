<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class loginControllers extends Controller
{
    public function index(){
        return view('login');
    }

    public function Register(Request $req){
        DB::table('tbl_user')->insert([
            'username' => $req->username,
            'email' => $req->email,
            'password' => $req->password
        ]);

        return redirect('/login');
    }

    public function Login(Request $req){
        $user = DB::table('tbl_user')->where('username', $req->username)->first();
        if($user->password == $req->password){
            $req->session()->put('id_user', $user->id_user);
            return redirect('/');
        }else{
            return redirect('login');
        }
    }

    public function Logout(){
        Session::forget('id_user');
        return redirect('/');
    }
}
