<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\tbl_goods;
use Illuminate\Support\Facades\DB;

class firstControllers extends Controller
{
    public function index(){
        $goods = DB::table('tbl_goods')->get();
        return view('first',['goods' => $goods]);
    }

    public function store(Request $req){
        $this->validate($req ,[
            'file' => 'required|max: 2048'
        ]);
        $file = $req->file('file');
        $fileName = $file->getClientOriginalName();
        $upploadAddress = 'data_file';
        if($file->move($upploadAddress, $fileName)){
            $data = tbl_goods::create([
                'product_name' => $req->product_name,
                'price' => $req->price,
                'picture' => $fileName,
                'amount' => $req->amount
            ]);
            $res['message'] = "Success!";
            $res['value'] = $data;
            return response($res);
        }
    }

    public function getData(){
        $data = DB::table('tbl_goods')->get();
        if(count($data) > 0){
            $res['message'] = "Success!";
            $res['value'] = $data;
            return response($res);
        }else{
            $res['message'] = "Empty!";
            $res['value'] = $data;
            return response($res);
        }
    }
}
