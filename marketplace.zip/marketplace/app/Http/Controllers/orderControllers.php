<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class orderControllers extends Controller
{
    public function order(Request $req){
        DB::table('tbl_cart')->insert([
            'id_user' => Session::get('id_user'),
            'id_goods' => $req->id_goods,
            'amount' => $req->amount 
        ]);
        return redirect('/');
    }

    public function cart(){
        $cart = DB::table('cart')->get();
        return view('cart', ['cart' => $cart]);
    }

    public function checkout(){
        $id_checkout = rand();
        $total = 0;
        $data = DB::table('tbl_cart')->where('id_user', Session::get('id_user'))->get();
        foreach($data as $crt){
            $goods = DB::table('tbl_goods')->where('id_goods', $crt->id_goods)->get();
            foreach($goods as $gds){
                $total += ($crt->amount * $gds->price);
                DB::table('checkout')->insert([
                    'id_checkout' => $id_checkout,
                    'id_goods' => $crt->id_goods,
                    'amount' => $crt->amount
                ]);
            }
        }
        DB::table('tbl_checkout')->insert([
            'id' => $id_checkout,
            'id_user' => Session::get('id_user'),
            'total' => $total
        ]);

        return redirect('/checkout');
    }

    public function checkoutList(){
        $checkout = DB::table('detail_checkout')->get();
        return view('checkout', ['checkout' => $checkout]);
    }

    public function confirm(){
        return view('/confirm');
    }

    public function saveConfirm(Request $req){
        $this->validate($req, [
            'file' => 'required|max: 2048'
        ]);
        
        $file = $req->file('file');
        $fileName = $file->getClientOriginalName();
        $upploadAddress = 'data_file';
        if($file->move($upploadAddress, $fileName)){
            DB::table('tbl_confirm')->insert([
                'id_user' => Session::get('id_user'),
                'id_checkout' => $req->id_token,
                'proof' => $fileName
            ]);

            return redirect('/');
        }
    }
}
