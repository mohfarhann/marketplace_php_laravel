<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_goods extends Model
{
    public $timestamps = false;
    protected $table = 'tbl_goods';
    protected $fillable = [
        'product_name',
        'price',
        'picture',
        'amount'
    ];
}
